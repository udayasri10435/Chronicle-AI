/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Type, GenerateContentResponse, ThinkingLevel } from "@google/genai";
import { 
  Backpack, 
  ScrollText, 
  ChevronRight, 
  Loader2, 
  Image as ImageIcon, 
  Settings, 
  RefreshCw,
  Sword,
  Shield,
  Map,
  User,
  MessageSquare,
  Send,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface GameState {
  storyText: string;
  choices: string[];
  inventory: string[];
  currentQuest: string;
  visualDescription: string;
  imageUrl: string | null;
  combat?: CombatState;
}

interface CombatState {
  enemy: Enemy;
  playerHp: number;
  playerMaxHp: number;
  combatLog: string[];
  isPlayerTurn: boolean;
  isFinished: boolean;
  outcome?: 'victory' | 'defeat' | 'fled';
}

interface Enemy {
  name: string;
  hp: number;
  maxHp: number;
  description: string;
  abilities: string[];
}

interface Ability {
  name: string;
  description: string;
  type: 'damage' | 'heal' | 'buff' | 'debuff';
  value: number;
}

interface CharacterInfo {
  name: string;
  class: string;
  description: string;
  abilities: Ability[];
}

// --- Constants ---

const CLASS_ABILITIES: Record<string, Ability[]> = {
  "Rogue": [
    { name: "Backstab", description: "A high-damage strike from the shadows.", type: 'damage', value: 25 },
    { name: "Poison Blade", description: "Deals moderate damage and weakens the enemy.", type: 'damage', value: 15 },
    { name: "Vanish", description: "Attempt to escape the combat.", type: 'buff', value: 0 }
  ],
  "Mage": [
    { name: "Fireball", description: "A powerful blast of arcane fire.", type: 'damage', value: 30 },
    { name: "Arcane Shield", description: "Protects you from incoming damage.", type: 'heal', value: 20 },
    { name: "Frostbolt", description: "Slows the enemy and deals damage.", type: 'damage', value: 15 }
  ],
  "Warrior": [
    { name: "Cleave", description: "A heavy swing that deals massive damage.", type: 'damage', value: 25 },
    { name: "Shield Wall", description: "Brace for impact, reducing damage.", type: 'heal', value: 25 },
    { name: "Pummel", description: "Interrupt the enemy's next move.", type: 'damage', value: 10 }
  ],
  "Paladin": [
    { name: "Holy Strike", description: "A righteous blow infused with light.", type: 'damage', value: 20 },
    { name: "Lay on Hands", description: "Heal your wounds significantly.", type: 'heal', value: 40 },
    { name: "Consecration", description: "Burn the ground beneath the enemy.", type: 'damage', value: 15 }
  ],
  "Ranger": [
    { name: "Aimed Shot", description: "A precise arrow to a vital spot.", type: 'damage', value: 30 },
    { name: "Trap", description: "Stun the enemy for a turn.", type: 'damage', value: 10 },
    { name: "Mend Wounds", description: "A quick herbal remedy to heal.", type: 'heal', value: 20 }
  ]
};

const STORY_MODEL = "gemini-3.1-pro-preview";
const IMAGE_MODEL = "gemini-3-pro-image-preview";
const QUICK_MODEL = "gemini-3.1-flash-lite-preview";

const ART_STYLE = "Digital art, cinematic lighting, high fantasy, detailed textures, vibrant colors, consistent character appearance.";

// --- App Component ---

export default function App() {
  const [gameState, setGameState] = useState<'setup' | 'playing' | 'loading' | 'error'>('setup');
  const [character, setCharacter] = useState<CharacterInfo>({ name: '', class: '', description: '' });
  const [currentStep, setCurrentStep] = useState<GameState | null>(null);
  const [history, setHistory] = useState<GameState[]>([]);
  const [imageSize, setImageSize] = useState<"1K" | "2K" | "4K">("1K");
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [currentStep]);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages, isChatOpen]);

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

  // --- Chat Logic ---

  const sendMessageToDM = async () => {
    if (!chatInput.trim() || isChatLoading) return;

    const userMessage: Message = { role: 'user', text: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');
    setIsChatLoading(true);

    try {
      const chat = ai.chats.create({
        model: QUICK_MODEL,
        config: {
          systemInstruction: `
            You are the Dungeon Master of this adventure. 
            The player is: ${character.name}, a ${character.class}.
            Current Quest: ${currentStep?.currentQuest || 'None'}
            Inventory: ${currentStep?.inventory.join(', ') || 'None'}
            
            Be helpful, mysterious, and stay in character. 
            You can answer questions about the world, the rules, or the character's status.
            Do not reveal spoilers or future plot points unless it makes sense for a DM to do so.
          `,
        },
        history: chatMessages.map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        }))
      });

      const response = await chat.sendMessage({ message: chatInput });
      const dmMessage: Message = { role: 'model', text: response.text || "I'm at a loss for words..." };
      setChatMessages(prev => [...prev, dmMessage]);
    } catch (err) {
      console.error(err);
      setChatMessages(prev => [...prev, { role: 'model', text: "The connection to the ethereal plane is weak. Try again later." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // --- AI Logic ---

  const generateStoryStep = async (choice?: string) => {
    setGameState('loading');
    setError(null);

    try {
      const systemInstruction = `
        You are the Dungeon Master of an infinite choose-your-own-adventure game.
        Your goal is to create a compelling, reactive narrative based on the player's choices.
        
        Character: ${character.name} (${character.class}) - ${character.description}
        Current Inventory: ${currentStep?.inventory.join(', ') || 'None'}
        Current Quest: ${currentStep?.currentQuest || 'Begin the journey'}
        
        Rules:
        1. The story must be immersive and descriptive.
        2. Choices should be meaningful and alter the plot significantly.
        3. Update the inventory and quest dynamically.
        4. Provide a visual description for an image generator that maintains character consistency.
        5. If the narrative leads to a fight, include a "combat" object in the JSON.
        
        Output MUST be valid JSON with this schema:
        {
          "storyText": "string",
          "choices": ["string", "string", "string"],
          "inventoryUpdate": { "add": ["string"], "remove": ["string"] },
          "questUpdate": "string",
          "visualPrompt": "string (description of the scene including the character)",
          "combat": {
            "enemy": {
              "name": "string",
              "hp": number,
              "maxHp": number,
              "description": "string",
              "abilities": ["string"]
            }
          } (optional)
        }
      `;

      const prompt = choice 
        ? `The player chose: "${choice}". Continue the story.`
        : `Start the adventure for ${character.name} the ${character.class} in a ${character.description} setting.`;

      const response = await ai.models.generateContent({
        model: STORY_MODEL,
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              storyText: { type: Type.STRING },
              choices: { type: Type.ARRAY, items: { type: Type.STRING } },
              inventoryUpdate: {
                type: Type.OBJECT,
                properties: {
                  add: { type: Type.ARRAY, items: { type: Type.STRING } },
                  remove: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              questUpdate: { type: Type.STRING },
              visualPrompt: { type: Type.STRING },
              combat: {
                type: Type.OBJECT,
                properties: {
                  enemy: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      hp: { type: Type.NUMBER },
                      maxHp: { type: Type.NUMBER },
                      description: { type: Type.STRING },
                      abilities: { type: Type.ARRAY, items: { type: Type.STRING } }
                    },
                    required: ["name", "hp", "maxHp", "description", "abilities"]
                  }
                },
                required: ["enemy"]
              }
            },
            required: ["storyText", "choices", "inventoryUpdate", "questUpdate", "visualPrompt"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      
      // Update inventory
      const newInventory = [...(currentStep?.inventory || [])];
      data.inventoryUpdate.add?.forEach((item: string) => {
        if (!newInventory.includes(item)) newInventory.push(item);
      });
      data.inventoryUpdate.remove?.forEach((item: string) => {
        const index = newInventory.indexOf(item);
        if (index > -1) newInventory.splice(index, 1);
      });

      const nextStep: GameState = {
        storyText: data.storyText,
        choices: data.choices,
        inventory: newInventory,
        currentQuest: data.questUpdate,
        visualDescription: data.visualPrompt,
        imageUrl: null,
        combat: data.combat ? {
          enemy: data.combat.enemy,
          playerHp: currentStep?.combat?.playerHp || 100,
          playerMaxHp: 100,
          combatLog: [`A ${data.combat.enemy.name} appears!`],
          isPlayerTurn: true,
          isFinished: false
        } : undefined
      };

      setCurrentStep(nextStep);
      setGameState('playing');
      
      // Generate image in background
      generateImage(data.visualPrompt, nextStep);

    } catch (err) {
      console.error(err);
      setError("Failed to generate the next chapter. Please try again.");
      setGameState('playing');
    }
  };

  const generateImage = async (visualPrompt: string, step: GameState) => {
    setIsGeneratingImage(true);
    try {
      const fullPrompt = `${ART_STYLE} Scene: ${visualPrompt}. Character: ${character.name}, ${character.class}, ${character.description}.`;
      
      const response = await ai.models.generateContent({
        model: IMAGE_MODEL,
        contents: { parts: [{ text: fullPrompt }] },
        config: {
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: imageSize
          }
        }
      });

      let imageUrl = null;
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setCurrentStep(prev => prev === step ? { ...prev, imageUrl } : prev);
      }
    } catch (err) {
      console.error("Image generation failed:", err);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const executeCombatTurn = async (action: { type: 'attack' | 'ability' | 'item', value?: string }) => {
    if (!currentStep?.combat || currentStep.combat.isFinished) return;

    setGameState('loading');
    const combat = currentStep.combat;
    const enemy = combat.enemy;

    try {
      const systemInstruction = `
        You are the Combat Engine for an RPG.
        Process the player's turn and the enemy's counter-attack.
        
        Player: ${character.name} (${character.class}) - HP: ${combat.playerHp}/${combat.playerMaxHp}
        Enemy: ${enemy.name} - HP: ${enemy.hp}/${enemy.maxHp}
        Player Action: ${action.type} ${action.value || ''}
        
        Rules:
        1. Calculate damage/healing based on the action.
        2. If the enemy is still alive, they must counter-attack.
        3. Provide a short, exciting description of the exchange.
        4. Update the combat log.
        5. Determine if the combat is finished (Victory or Defeat).
        
        Output MUST be valid JSON with this schema:
        {
          "logEntries": ["string"],
          "playerHpChange": number,
          "enemyHpChange": number,
          "isFinished": boolean,
          "outcome": "victory" | "defeat" | "fled" | null
        }
      `;

      const response = await ai.models.generateContent({
        model: QUICK_MODEL,
        contents: `Process combat turn.`,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              logEntries: { type: Type.ARRAY, items: { type: Type.STRING } },
              playerHpChange: { type: Type.NUMBER },
              enemyHpChange: { type: Type.NUMBER },
              isFinished: { type: Type.BOOLEAN },
              outcome: { type: Type.STRING, nullable: true }
            },
            required: ["logEntries", "playerHpChange", "enemyHpChange", "isFinished", "outcome"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      
      const newPlayerHp = Math.max(0, Math.min(combat.playerMaxHp, combat.playerHp + data.playerHpChange));
      const newEnemyHp = Math.max(0, Math.min(enemy.maxHp, enemy.hp + data.enemyHpChange));

      const updatedCombat: CombatState = {
        ...combat,
        playerHp: newPlayerHp,
        enemy: { ...enemy, hp: newEnemyHp },
        combatLog: [...combat.combatLog, ...data.logEntries],
        isFinished: data.isFinished || newPlayerHp <= 0 || newEnemyHp <= 0,
        outcome: data.outcome || (newEnemyHp <= 0 ? 'victory' : newPlayerHp <= 0 ? 'defeat' : undefined)
      };

      setCurrentStep({ ...currentStep, combat: updatedCombat });
      setGameState('playing');

      if (updatedCombat.isFinished && updatedCombat.outcome === 'victory') {
        // Automatically transition back to story after a short delay or via a button
      }

    } catch (err) {
      console.error(err);
      setError("Combat error. Please try again.");
      setGameState('playing');
    }
  };

  const handleCombatEnd = () => {
    if (!currentStep?.combat) return;
    if (currentStep.combat.outcome === 'victory') {
      generateStoryStep(`I have defeated the ${currentStep.combat.enemy.name}.`);
    } else if (currentStep.combat.outcome === 'defeat') {
      setGameState('setup'); // Game over
    } else {
      generateStoryStep(`I managed to flee from the ${currentStep.combat.enemy.name}.`);
    }
  };

  const startNewGame = () => {
    if (!character.name || !character.class) return;
    const abilities = CLASS_ABILITIES[character.class] || [];
    setCharacter(prev => ({ ...prev, abilities }));
    generateStoryStep();
  };

  // --- Render Helpers ---

  const CombatUI = ({ combat }: { combat: CombatState }) => {
    const [showAbilities, setShowAbilities] = useState(false);
    const [showInventory, setShowInventory] = useState(false);

    return (
      <div className="space-y-8">
        {/* Combat Header */}
        <div className="flex items-center justify-between gap-8">
          {/* Player Stats */}
          <div className="flex-1 space-y-2">
            <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-white/40">
              <span>{character.name}</span>
              <span>{combat.playerHp} / {combat.playerMaxHp} HP</span>
            </div>
            <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/10">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(combat.playerHp / combat.playerMaxHp) * 100}%` }}
                className="h-full bg-green-500"
              />
            </div>
          </div>

          <div className="text-2xl font-black text-white/10 italic">VS</div>

          {/* Enemy Stats */}
          <div className="flex-1 space-y-2">
            <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-white/40">
              <span>{combat.enemy.name}</span>
              <span>{combat.enemy.hp} / {combat.enemy.maxHp} HP</span>
            </div>
            <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/10">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(combat.enemy.hp / combat.enemy.maxHp) * 100}%` }}
                className="h-full bg-red-500"
              />
            </div>
          </div>
        </div>

        {/* Combat Log */}
        <div className="bg-black/40 border border-white/5 rounded-2xl p-6 h-48 overflow-y-auto font-mono text-sm space-y-2">
          {combat.combatLog.map((log, i) => (
            <div key={i} className="text-white/60">
              <span className="text-indigo-500 mr-2">[{i + 1}]</span>
              {log}
            </div>
          ))}
        </div>

        {/* Combat Actions */}
        {!combat.isFinished ? (
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => executeCombatTurn({ type: 'attack' })}
              className="bg-white text-black font-bold py-4 rounded-xl hover:bg-indigo-500 hover:text-white transition-all flex items-center justify-center gap-2"
            >
              <Sword className="w-5 h-5" />
              Basic Attack
            </button>
            <button 
              onClick={() => setShowAbilities(!showAbilities)}
              className="bg-white/5 border border-white/10 font-bold py-4 rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2"
            >
              <Shield className="w-5 h-5" />
              Abilities
            </button>
            <button 
              onClick={() => setShowInventory(!showInventory)}
              className="bg-white/5 border border-white/10 font-bold py-4 rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2"
            >
              <Backpack className="w-5 h-5" />
              Use Item
            </button>
            <button 
              onClick={() => executeCombatTurn({ type: 'ability', value: 'Flee' })}
              className="bg-white/5 border border-white/10 font-bold py-4 rounded-xl hover:bg-red-500/20 hover:text-red-400 transition-all flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-5 h-5" />
              Attempt Flee
            </button>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-indigo-600 rounded-2xl p-8 text-center space-y-4"
          >
            <h3 className="text-3xl font-black uppercase italic tracking-tighter">
              {combat.outcome === 'victory' ? 'Victory!' : combat.outcome === 'defeat' ? 'Defeated' : 'Escaped'}
            </h3>
            <p className="text-white/80">
              {combat.outcome === 'victory' 
                ? `You have triumphed over the ${combat.enemy.name}.` 
                : combat.outcome === 'defeat' 
                ? 'Your journey ends here...' 
                : 'You managed to slip away into the shadows.'}
            </p>
            <button 
              onClick={handleCombatEnd}
              className="bg-white text-black font-bold px-8 py-3 rounded-xl hover:bg-indigo-100 transition-all"
            >
              {combat.outcome === 'defeat' ? 'Restart' : 'Continue Story'}
            </button>
          </motion.div>
        )}

        {/* Ability Modal */}
        <AnimatePresence>
          {showAbilities && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
            >
              <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-md w-full space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold">Class Abilities</h3>
                  <button onClick={() => setShowAbilities(false)} className="text-white/40 hover:text-white">✕</button>
                </div>
                <div className="space-y-3">
                  {character.abilities.map((ability, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        executeCombatTurn({ type: 'ability', value: ability.name });
                        setShowAbilities(false);
                      }}
                      className="w-full text-left bg-white/5 border border-white/5 p-4 rounded-xl hover:bg-indigo-500/10 hover:border-indigo-500/50 transition-all group"
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold group-hover:text-indigo-200">{ability.name}</span>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-white/30">{ability.type}</span>
                      </div>
                      <p className="text-xs text-white/50">{ability.description}</p>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Inventory Modal */}
        <AnimatePresence>
          {showInventory && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm"
            >
              <div className="bg-[#151515] border border-white/10 rounded-2xl p-8 max-w-md w-full space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold">Use Item</h3>
                  <button onClick={() => setShowInventory(false)} className="text-white/40 hover:text-white">✕</button>
                </div>
                <div className="space-y-3">
                  {currentStep?.inventory.length === 0 ? (
                    <p className="text-center py-8 text-white/20 italic">No items to use...</p>
                  ) : (
                    currentStep?.inventory.map((item, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          executeCombatTurn({ type: 'item', value: item });
                          setShowInventory(false);
                        }}
                        className="w-full text-left bg-white/5 border border-white/5 p-4 rounded-xl hover:bg-indigo-500/10 hover:border-indigo-500/50 transition-all"
                      >
                        <span className="font-bold">{item}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  if (gameState === 'setup') {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-[#151515] border border-white/10 rounded-2xl p-8 shadow-2xl"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 bg-indigo-600 rounded-xl">
              <Sword className="w-6 h-6" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Chronicle AI</h1>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest text-white/50 mb-2">Character Name</label>
              <input 
                type="text" 
                value={character.name}
                onChange={(e) => setCharacter({ ...character, name: e.target.value })}
                placeholder="e.g. Elara Shadowstep"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest text-white/50 mb-2">Class / Role</label>
              <select 
                value={character.class}
                onChange={(e) => setCharacter({ ...character, class: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-indigo-500 transition-colors appearance-none"
              >
                <option value="" disabled>Select your path...</option>
                <option value="Rogue">Rogue</option>
                <option value="Mage">Mage</option>
                <option value="Warrior">Warrior</option>
                <option value="Paladin">Paladin</option>
                <option value="Ranger">Ranger</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-widest text-white/50 mb-2">Setting / Vibe</label>
              <textarea 
                value={character.description}
                onChange={(e) => setCharacter({ ...character, description: e.target.value })}
                placeholder="e.g. A dark gothic city overrun by clockwork automatons"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-indigo-500 transition-colors h-24 resize-none"
              />
            </div>

            <div className="pt-4">
              <label className="block text-xs font-semibold uppercase tracking-widest text-white/50 mb-2">Image Quality</label>
              <div className="flex gap-2">
                {(["1K", "2K", "4K"] as const).map((size) => (
                  <button
                    key={size}
                    onClick={() => setImageSize(size)}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                      imageSize === size ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40 hover:bg-white/10'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={startNewGame}
              disabled={!character.name || !character.class}
              className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-indigo-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              Begin Adventure
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-80 bg-[#111] border-r border-white/10 flex flex-col shrink-0">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-bold text-sm leading-tight">{character.name}</h2>
              <p className="text-xs text-white/40">{character.class}</p>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-white/30 uppercase tracking-widest mb-2">
              <ScrollText className="w-3 h-3" />
              Current Quest
            </div>
            <div className="bg-white/5 rounded-xl p-4 border border-white/5">
              <p className="text-sm leading-relaxed italic text-indigo-200">
                {currentStep?.currentQuest || "Awaiting destiny..."}
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-white/30 uppercase tracking-widest mb-4">
            <Backpack className="w-3 h-3" />
            Inventory
          </div>
          <div className="space-y-2">
            {currentStep?.inventory.length === 0 ? (
              <p className="text-sm text-white/20 italic">Empty pockets...</p>
            ) : (
              currentStep?.inventory.map((item, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i} 
                  className="bg-white/5 border border-white/5 rounded-lg px-3 py-2 text-sm flex items-center gap-2"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  {item}
                </motion.div>
              ))
            )}
          </div>
        </div>

        <div className="p-6 border-t border-white/10">
          <button 
            onClick={() => setIsChatOpen(true)}
            className="w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition-all mb-4"
          >
            <MessageSquare className="w-4 h-4" />
            Chat with DM
          </button>
          <button 
            onClick={() => setGameState('setup')}
            className="w-full flex items-center justify-center gap-2 text-xs font-bold text-white/40 hover:text-white transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            Restart Journey
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative">
        {/* Chat Overlay */}
        <AnimatePresence>
          {isChatOpen && (
            <motion.div 
              initial={{ opacity: 0, x: 300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 300 }}
              className="absolute right-0 top-0 bottom-0 w-96 bg-[#151515] border-l border-white/10 z-50 flex flex-col shadow-2xl"
            >
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-[#1a1a1a]">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-indigo-500" />
                  <span className="font-bold text-sm uppercase tracking-widest">Dungeon Master</span>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="text-white/40 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMessages.length === 0 && (
                  <div className="text-center py-8 text-white/20 italic text-sm">
                    Ask the DM anything about your journey...
                  </div>
                )}
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-3 rounded-2xl text-sm ${
                      msg.role === 'user' 
                        ? 'bg-indigo-600 text-white rounded-tr-none' 
                        : 'bg-white/5 border border-white/10 text-white/80 rounded-tl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white/5 border border-white/10 p-3 rounded-2xl rounded-tl-none">
                      <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 border-t border-white/10 bg-[#1a1a1a]">
                <form 
                  onSubmit={(e) => { e.preventDefault(); sendMessageToDM(); }}
                  className="flex gap-2"
                >
                  <input 
                    type="text" 
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                  <button 
                    type="submit"
                    disabled={!chatInput.trim() || isChatLoading}
                    className="p-2 bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {/* Header */}
        <header className="h-16 border-b border-white/10 flex items-center justify-between px-8 shrink-0 bg-[#0a0a0a]/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-2">
            <Map className="w-4 h-4 text-indigo-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-white/60">The Chronicle</span>
          </div>
          <div className="flex items-center gap-4">
            {isGeneratingImage && (
              <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-400 uppercase tracking-tighter">
                <Loader2 className="w-3 h-3 animate-spin" />
                Painting Scene...
              </div>
            )}
            <div className="h-4 w-px bg-white/10" />
            <div className="flex items-center gap-2 text-xs text-white/40">
              <Settings className="w-3 h-3" />
              {imageSize}
            </div>
          </div>
        </header>

        {/* Story Area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth">
          <AnimatePresence mode="wait">
            {currentStep && (
              <motion.div 
                key={currentStep.storyText}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="max-w-3xl mx-auto space-y-8"
              >
                {/* Visual */}
                <div className="aspect-video w-full bg-white/5 rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative group">
                  {currentStep.imageUrl ? (
                    <img 
                      src={currentStep.imageUrl} 
                      alt="Story Scene" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-4 text-white/20">
                      <ImageIcon className="w-12 h-12" />
                      <p className="text-xs font-bold uppercase tracking-widest">Visualizing...</p>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                    <p className="text-[10px] text-white/60 line-clamp-2 italic">{currentStep.visualDescription}</p>
                  </div>
                </div>

                {/* Text or Combat */}
                <div className="space-y-6">
                  {currentStep.combat ? (
                    <CombatUI combat={currentStep.combat} />
                  ) : (
                    <>
                      <p className="text-xl leading-relaxed text-white/90 font-serif first-letter:text-5xl first-letter:font-bold first-letter:mr-3 first-letter:float-left first-letter:text-indigo-500">
                        {currentStep.storyText}
                      </p>
                      
                      {/* Choices */}
                      <div className="grid grid-cols-1 gap-3 pt-8">
                        {gameState === 'loading' ? (
                          <div className="flex items-center justify-center py-12">
                            <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
                          </div>
                        ) : (
                          currentStep.choices.map((choice, i) => (
                            <button
                              key={i}
                              onClick={() => generateStoryStep(choice)}
                              className="group flex items-center justify-between bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-indigo-500/10 p-5 rounded-2xl transition-all text-left"
                            >
                              <span className="text-sm font-medium group-hover:text-indigo-200 transition-colors">{choice}</span>
                              <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-indigo-500 transition-colors" />
                            </button>
                          ))
                        )}
                      </div>
                    </>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {error && (
            <div className="max-w-md mx-auto bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-center">
              <p className="text-sm text-red-400 mb-3">{error}</p>
              <button 
                onClick={() => generateStoryStep()}
                className="text-xs font-bold uppercase tracking-widest bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors"
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
